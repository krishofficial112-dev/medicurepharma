export type Product = {
  id: string; business_id: string; sku: string; name: string; generic_name: string | null;
  manufacturer: string | null; hsn_code: string | null; gst_rate: number; unit: string;
  mrp: number; purchase_price: number; reorder_level: number; is_active: boolean;
};
export type Batch = {
  id: string; business_id: string; product_id: string; batch_no: string;
  expiry_date: string | null; quantity: number; purchase_rate: number; mrp: number;
};
export type CartLine = { product: Product; batch: Batch; quantity: number };
export type InvoiceDraft = {
  id: string; invoice_no: string; customer_name: string; customer_gstin: string;
  supply_type: "intra" | "inter"; payment_method: string; created_at: string;
  subtotal: number; cgst: number; sgst: number; igst: number; grand_total: number;
  lines: Array<{ product_id: string; batch_id: string; product_name: string; batch_no: string;
    quantity: number; unit_price: number; gst_rate: number; taxable_value: number;
    cgst: number; sgst: number; igst: number; line_total: number }>;
};
