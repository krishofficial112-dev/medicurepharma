import {useEffect,useState} from 'react';
import {Boxes,LayoutDashboard,LogOut,Menu,Pill,RefreshCw,ShoppingCart,X,FileText,Users,HardDrive} from 'lucide-react';
import type {Batch,Product} from './types';
import {localDb,setLocalUser} from './lib/db';
import {validateLocalSession,signOutLocal,type LocalUser} from './lib/localAuth';
import SignIn from './components/SignIn';import Dashboard from './pages/Dashboard';import Inventory from './pages/Inventory';import POS from './pages/POS';import Sync from './pages/Sync';import Quotations from './pages/Quotations';import Admin from './pages/Admin';import CompanyHome from './CompanyHome';
type Page='dashboard'|'pos'|'inventory'|'quotations'|'sync'|'admin';
export default function App(){
 const [mode,setMode]=useState<'company'|'billing'>('company'); const [user,setUser]=useState<LocalUser|null>(null),[ready,setReady]=useState(false),[page,setPage]=useState<Page>('dashboard'),[products,setProducts]=useState<Product[]>([]),[batches,setBatches]=useState<Batch[]>([]),[pending,setPending]=useState(0),[menuOpen,setMenuOpen]=useState(false);
 async function loadLocal(){setProducts(await localDb.products.toArray());setBatches(await localDb.batches.toArray());setPending(await localDb.pendingInvoices.count());}
 async function refresh(){await loadLocal();}
 async function login(next:LocalUser){await setLocalUser(next.id);setUser(next);setPage('dashboard');await loadLocal();}
 function logout(){signOutLocal();setUser(null);setPage('dashboard');}
 useEffect(()=>{let alive=true;void(async()=>{try{const saved=await validateLocalSession();if(saved&&alive){await setLocalUser(saved.id);setUser(saved);await loadLocal();}}finally{if(alive)setReady(true);}})();return()=>{alive=false;};},[]);
 useEffect(()=>{if(user)void loadLocal();},[user]);
 if(mode==='company')return <CompanyHome openBilling={()=>setMode('billing')}/>;
 if(!ready)return <div className="loading-screen">Loading Desk Billing…</div>;
 if(!user)return <SignIn onLogin={u=>void login(u)}/>;
 const role=user.role;
 const nav=[{id:'dashboard' as Page,label:'Dashboard',icon:LayoutDashboard},{id:'pos' as Page,label:'Point of Sale',icon:ShoppingCart},{id:'inventory' as Page,label:'Inventory',icon:Boxes},{id:'quotations' as Page,label:'Quotations',icon:FileText},{id:'sync' as Page,label:'Local data & backup',icon:HardDrive},...(role==='admin'?[{id:'admin' as Page,label:'User management',icon:Users}]:[])];
 function go(p:Page){setPage(p);setMenuOpen(false);}
 return <div className="app-shell"><div className={`mobile-scrim ${menuOpen?'visible':''}`} onClick={()=>setMenuOpen(false)}></div><aside className={`sidebar ${menuOpen?'sidebar-open':''}`}><div className="logo-row"><div className="brand-mark small">DB</div><div><b>DESK BILLING</b><small>LOCAL BUSINESS WORKSPACE</small></div><button className="mobile-close icon-button" onClick={()=>setMenuOpen(false)} aria-label="Close menu"><X/></button></div><button className="business-chip" onClick={()=>setMode('company')}><Pill size={15}/> Company website</button><div className="business-chip"><Pill size={15}/> Private device workspace</div><nav>{nav.map(n=><button key={n.id} className={page===n.id?'active':''} onClick={()=>go(n.id)}><n.icon size={18}/>{n.label}</button>)}</nav><div className="sidebar-bottom"><div className="connection"><span className="online-dot"></span>Stored on this device</div><button className="logout" onClick={logout}><LogOut size={17}/> Sign out</button></div></aside>
 <main className="main-area"><header className="topbar"><div className="topbar-left"><button className="mobile-menu icon-button" onClick={()=>setMenuOpen(true)} aria-label="Open navigation"><Menu/></button><div><span className="mobile-brand">DESK BILLING</span><span className="crumb">{user.name} / {nav.find(n=>n.id===page)?.label}</span></div></div><div className="top-actions"><span className="connection-pill"><HardDrive size={15}/> Local storage</span><button className="icon-button" title="Refresh local data" onClick={()=>void refresh()}><RefreshCw size={17}/></button></div></header>
 {page==='dashboard'&&<Dashboard products={products} batches={batches} pending={pending}/ >}{page==='pos'&&<POS products={products} batches={batches} onSaved={loadLocal}/ >}{page==='inventory'&&<Inventory products={products} batches={batches} reload={refresh} userId={user.id}/ >}{page==='quotations'&&<Quotations/>}{page==='sync'&&<Sync refresh={refresh}/ >}{page==='admin'&&role==='admin'&&<Admin currentUser={user}/>}
 <footer>DESK BILLING <span>· Made By Krish Garg</span> · Data stays in this browser</footer></main></div>;
}
