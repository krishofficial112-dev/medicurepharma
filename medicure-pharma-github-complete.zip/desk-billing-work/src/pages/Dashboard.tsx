import type { Product, Batch } from "../types";
export default function Dashboard({ products, batches, pending }: { products: Product[]; batches: Batch[]; pending: number }) {
  const stock = batches.reduce((n,b)=>n+Number(b.quantity),0);
  const low = products.filter(p => batches.filter(b=>b.product_id===p.id).reduce((n,b)=>n+Number(b.quantity),0) <= Number(p.reorder_level)).length;
  return <div className="page">
    <div className="page-heading"><div><p className="eyebrow">OVERVIEW</p><h2>Good day. Here's your pharmacy at a glance.</h2><p className="muted">Your local catalogue stays available when you go offline.</p></div></div>
    <div className="stat-grid">
      <div className="stat-card"><span>Active products</span><strong>{products.length}</strong><small>In your catalogue</small></div>
      <div className="stat-card"><span>Units in stock</span><strong>{stock.toLocaleString("en-IN")}</strong><small>Across loaded batches</small></div>
      <div className="stat-card"><span>Low-stock items</span><strong>{low}</strong><small>At or below reorder level</small></div>
      <div className="stat-card"><span>Invoices saved</span><strong>{pending}</strong><small>Stored in this browser</small></div>
    </div>
    <div className="panel welcome-panel"><div><p className="eyebrow">PHASE 1 WORKSPACE</p><h3>Everything important, in one place.</h3><p className="muted">Use Point of Sale to bill customers, Inventory to manage medicine batches, and Local Data & Backup to protect your records.</p></div><div className="welcome-icon">✚</div></div>
    <div className="panel"><h3>Pharmacy operations checklist</h3><div className="check-row"><span className="check">✓</span><div><b>Catalogue and batch tracking</b><small>Products, batch numbers, expiry dates and quantities</small></div></div><div className="check-row"><span className="check">✓</span><div><b>GST-aware billing</b><small>Intra-state CGST/SGST and inter-state IGST calculation</small></div></div><div className="check-row"><span className="check">↻</span><div><b>Local invoice history</b><small>Invoices are stored in this browser on this device</small></div></div></div>
  </div>;
}
