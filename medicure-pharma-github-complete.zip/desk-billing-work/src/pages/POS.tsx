import { useMemo, useState } from "react";
import { Search, Trash2, ShoppingCart } from "lucide-react";
import type { Batch, CartLine, Product, InvoiceDraft } from "../types";
import { calculateCart } from "../lib/tax";
import { localDb } from "../lib/db";

export default function POS({ products, batches, onSaved }: { products: Product[]; batches: Batch[]; onSaved: () => Promise<void> }) {
  const [search,setSearch]=useState(""); const [cart,setCart]=useState<CartLine[]>([]);
  const [supply,setSupply]=useState<"intra"|"inter">("intra");
  const [customer,setCustomer]=useState(""); const [gstin,setGstin]=useState(""); const [payment,setPayment]=useState("cash");
  const [message,setMessage]=useState("");
  const filtered=products.filter(p=>`${p.name} ${p.sku} ${p.generic_name||""}`.toLowerCase().includes(search.toLowerCase()));
  const totals=useMemo(()=>calculateCart(cart,supply),[cart,supply]);
  function add(p:Product) {
    const available=batches.filter(b=>b.product_id===p.id && Number(b.quantity)>0).sort((a,b)=>(a.expiry_date||"9999").localeCompare(b.expiry_date||"9999"))[0];
    if(!available){setMessage(`No available batch for ${p.name}.`);return;}
    setCart(old=>{const found=old.find(x=>x.batch.id===available.id);if(found)return old.map(x=>x.batch.id===available.id?{...x,quantity:Math.min(x.quantity+1,Number(available.quantity))}:x);return [...old,{product:p,batch:available,quantity:1}];});
    setMessage("");
  }
  function changeQty(batchId:string,qty:number){setCart(old=>old.map(x=>x.batch.id===batchId?{...x,quantity:Math.max(1,Math.min(qty,Number(x.batch.quantity)))}:x));}
  async function checkout(){
    if(!cart.length)return;
    const now=new Date(); const id=crypto.randomUUID();
    const invoice:InvoiceDraft={id,invoice_no:`DB-${now.getFullYear()}${String(now.getMonth()+1).padStart(2,"0")}-${now.getTime().toString().slice(-6)}`,customer_name:customer,customer_gstin:gstin,supply_type:supply,payment_method:payment,created_at:now.toISOString(),subtotal:totals.subtotal,cgst:totals.cgst,sgst:totals.sgst,igst:totals.igst,grand_total:totals.grandTotal,
      lines:cart.map((x,i)=>({product_id:x.product.id,batch_id:x.batch.id,product_name:x.product.name,batch_no:x.batch.batch_no,quantity:x.quantity,unit_price:Number(x.batch.mrp),gst_rate:Number(x.product.gst_rate),taxable_value:totals.detail[i].taxable,cgst:totals.detail[i].cgst,sgst:totals.detail[i].sgst,igst:totals.detail[i].igst,line_total:totals.detail[i].total}))};
    try {
      await localDb.transaction('rw', localDb.pendingInvoices, localDb.batches, async () => {
        for (const line of cart) {
          const latest = await localDb.batches.get(line.batch.id);
          if (!latest || Number(latest.quantity) < line.quantity) {
            throw new Error(`Insufficient stock for ${line.product.name}. Refresh the bill and try again.`);
          }
        }
        for (const line of cart) {
          const latest = await localDb.batches.get(line.batch.id);
          if (latest) await localDb.batches.update(line.batch.id, { quantity: Number(latest.quantity) - line.quantity });
        }
        await localDb.pendingInvoices.add(invoice);
      });
      setCart([]);setCustomer("");setGstin("");setMessage(`Invoice ${invoice.invoice_no} saved on this device. Stock has been updated.`);await onSaved();
    } catch (err) {
      setMessage(err instanceof Error ? err.message : 'Could not save invoice.');
    }
  }
  return <div className="page"><div className="page-heading"><div><p className="eyebrow">CHECKOUT</p><h2>Point of Sale</h2><p className="muted">Fast billing with batch-aware stock selection and GST.</p></div><div className="pos-tag"><ShoppingCart size={16}/> {cart.length} lines</div></div>
    <div className="pos-layout"><section className="panel product-panel"><div className="searchbox"><Search size={18}/><input placeholder="Search medicine, generic or SKU…" value={search} onChange={e=>setSearch(e.target.value)}/></div><div className="product-grid">
      {filtered.map(p=>{const qty=batches.filter(b=>b.product_id===p.id).reduce((n,b)=>n+Number(b.quantity),0);return <button className="product-tile" key={p.id} onClick={()=>add(p)}><span className="medicine-icon">✚</span><b>{p.name}</b><small>{p.sku} · GST {p.gst_rate}%</small><strong>₹{Number(p.mrp).toFixed(2)}</strong><em>{qty} in stock</em></button>})}
      {!filtered.length&&<p className="empty">No matching medicines found.</p>}
    </div></section>
    <aside className="panel cart-panel"><h3>Current bill</h3><div className="cart-fields"><label>Customer<input value={customer} onChange={e=>setCustomer(e.target.value)} placeholder="Walk-in customer"/></label><label>Customer GSTIN<input value={gstin} onChange={e=>setGstin(e.target.value)} placeholder="Optional"/></label><label>Supply type<select value={supply} onChange={e=>setSupply(e.target.value as "intra"|"inter")}><option value="intra">Intra-state (CGST + SGST)</option><option value="inter">Inter-state (IGST)</option></select></label><label>Payment<select value={payment} onChange={e=>setPayment(e.target.value)}><option value="cash">Cash</option><option value="upi">UPI</option><option value="card">Card</option><option value="credit">Credit</option></select></label></div>
      <div className="cart-lines">{cart.map(x=><div className="cart-line" key={x.batch.id}><div className="cart-line-name"><b>{x.product.name}</b><small>{x.batch.batch_no} · ₹{Number(x.batch.mrp).toFixed(2)}</small></div><input aria-label="Quantity" type="number" min="1" max={x.batch.quantity} value={x.quantity} onChange={e=>changeQty(x.batch.id,Number(e.target.value))}/><button className="icon-button" onClick={()=>setCart(old=>old.filter(v=>v.batch.id!==x.batch.id))}><Trash2 size={16}/></button></div>)}
      {!cart.length&&<p className="empty">Add medicines from the catalogue to start billing.</p>}</div>
      <div className="totals"><div><span>Taxable value</span><b>₹{totals.subtotal.toFixed(2)}</b></div><div><span>CGST</span><b>₹{totals.cgst.toFixed(2)}</b></div><div><span>SGST</span><b>₹{totals.sgst.toFixed(2)}</b></div><div><span>IGST</span><b>₹{totals.igst.toFixed(2)}</b></div><div className="grand"><span>Total</span><strong>₹{totals.grandTotal.toFixed(2)}</strong></div></div>
      <button className="primary checkout" disabled={!cart.length} onClick={checkout}>Save invoice · ₹{totals.grandTotal.toFixed(2)}</button>{message&&<p className="notice">{message}</p>}
    </aside></div>
  </div>;
}
