import Dexie,{type Table} from 'dexie';
export type LocalAccount={id:string;name:string;email:string;role:'admin'|'staff';salt:string;passwordHash:string;active:boolean;createdAt:string};
class AccountsDB extends Dexie{accounts!:Table<LocalAccount,string>;constructor(){super('desk-billing-local-accounts');this.version(1).stores({accounts:'id,&email,role,active'});}}
const accountsDb=new AccountsDB();
const enc=new TextEncoder();
function toB64(bytes:Uint8Array){return btoa(String.fromCharCode(...bytes));}
function fromB64(value:string){return Uint8Array.from(atob(value),c=>c.charCodeAt(0));}
async function hashPassword(password:string,salt:string){const key=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveBits']);const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:fromB64(salt),iterations:210000,hash:'SHA-256'},key,256);return toB64(new Uint8Array(bits));}
export async function accountCount(){return accountsDb.accounts.count();}
export async function listAccounts(){return accountsDb.accounts.toArray();}
export async function createFirstAdmin(name:string,email:string,password:string){const count=await accountCount();if(count)throw new Error('An administrator already exists on this browser.');return createAccount(name,email,password,'admin');}
export async function createAccount(name:string,email:string,password:string,role:'admin'|'staff'='staff'){
 const normalized=email.trim().toLowerCase();if(!name.trim()||!normalized||password.length<10)throw new Error('Enter a name, valid email and password with at least 10 characters.');
 if(await accountsDb.accounts.where('email').equals(normalized).first())throw new Error('An account with this email already exists on this browser.');
 const id=crypto.randomUUID(),salt=toB64(crypto.getRandomValues(new Uint8Array(16))),passwordHash=await hashPassword(password,salt);
 const account:LocalAccount={id,name:name.trim(),email:normalized,role,salt,passwordHash,active:true,createdAt:new Date().toISOString()};await accountsDb.accounts.add(account);return publicAccount(account);
}
function publicAccount(a:LocalAccount){return {id:a.id,name:a.name,email:a.email,role:a.role,active:a.active,createdAt:a.createdAt};}
export async function signInLocal(email:string,password:string){const a=await accountsDb.accounts.where('email').equals(email.trim().toLowerCase()).first();if(!a||!a.active)throw new Error('Account not found or deactivated.');const candidate=await hashPassword(password,a.salt);if(candidate!==a.passwordHash)throw new Error('Incorrect email or password.');const user=publicAccount(a);localStorage.setItem('desk-billing-session',JSON.stringify(user));return user;}
export type LocalUser=ReturnType<typeof publicAccount>;
export function currentLocalUser():LocalUser|null{try{return JSON.parse(localStorage.getItem('desk-billing-session')||'null') as LocalUser|null;}catch{return null;}}
export async function validateLocalSession():Promise<LocalUser|null>{const cached=currentLocalUser();if(!cached)return null;const account=await accountsDb.accounts.get(cached.id);if(!account||!account.active){signOutLocal();return null;}const user=publicAccount(account);localStorage.setItem('desk-billing-session',JSON.stringify(user));return user;}
export function signOutLocal(){localStorage.removeItem('desk-billing-session');}
export async function setAccountActive(id:string,active:boolean){await accountsDb.accounts.update(id,{active});}
export async function deleteAccount(id:string,currentId:string){if(id===currentId)throw new Error('You cannot delete the account currently signed in.');const a=await accountsDb.accounts.get(id);if(a?.role==='admin'&&(await accountsDb.accounts.where('role').equals('admin').count())<=1)throw new Error('At least one administrator must remain.');await accountsDb.accounts.delete(id);}
