import type { CartLine } from "../types";

export function round2(n: number) { return Math.round((n + Number.EPSILON) * 100) / 100; }

export function calculateCart(lines: CartLine[], supplyType: "intra" | "inter") {
  const detail = lines.map((line) => {
    const taxable = round2(line.quantity * line.batch.mrp);
    const tax = round2(taxable * Number(line.product.gst_rate) / 100);
    const cgst = supplyType === "intra" ? round2(tax / 2) : 0;
    const sgst = supplyType === "intra" ? round2(tax - cgst) : 0;
    const igst = supplyType === "inter" ? tax : 0;
    return { taxable, cgst, sgst, igst, total: round2(taxable + tax) };
  });
  const subtotal = round2(detail.reduce((s, x) => s + x.taxable, 0));
  const cgst = round2(detail.reduce((s, x) => s + x.cgst, 0));
  const sgst = round2(detail.reduce((s, x) => s + x.sgst, 0));
  const igst = round2(detail.reduce((s, x) => s + x.igst, 0));
  return { detail, subtotal, cgst, sgst, igst, grandTotal: round2(subtotal + cgst + sgst + igst) };
}
