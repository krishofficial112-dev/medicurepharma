import Dexie,{type Table} from 'dexie';
import type {Batch,InvoiceDraft,Product} from '../types';
export type LocalQuotation = {id:string;quotation_no:string;customer_name:string;category:string;items:Array<{description:string;qty:number;rate:number;tax:number}>;subtotal:number;tax:number;total:number;notes:string;letterhead_data?:string;created_at:string};
class DeskBillingDB extends Dexie{
 products!:Table<Product,string>;batches!:Table<Batch,string>;pendingInvoices!:Table<InvoiceDraft,string>;quotations!:Table<LocalQuotation,string>;
 constructor(name:string){super(name);this.version(2).stores({products:'id,business_id,name,sku',batches:'id,business_id,product_id,batch_no,expiry_date',pendingInvoices:'id,invoice_no,created_at',quotations:'id,quotation_no,created_at'});}
}
export let localDb=new DeskBillingDB('desk-billing-guest');
export async function setLocalUser(userId:string){const name=`desk-billing-${userId.replace(/[^a-zA-Z0-9_-]/g,'')}`;if(localDb.name===name)return;localDb.close();localDb=new DeskBillingDB(name);await localDb.open();}
